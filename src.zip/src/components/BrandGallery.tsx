import { useState, useRef } from 'react';
import { brandDirections, BrandDirection } from '../data/brandDirections';
import BrandCard from './BrandCard';
import BrandModal from './BrandModal';
import FilterBar from './FilterBar';
import { useInView } from 'framer-motion';
import { motion } from 'framer-motion';

interface BrandGalleryProps {
  onPreference: (brandId: number, preference: 'love' | 'maybe' | 'no') => void;
}

export default function BrandGallery({ onPreference }: BrandGalleryProps) {
  const [selectedBrand, setSelectedBrand] = useState<BrandDirection | null>(null);
  const [selectedFilter, setSelectedFilter] = useState('All');
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const filteredBrands = brandDirections.filter((brand) => {
    if (selectedFilter === 'All') return true;
    return brand.tags.some((tag) => tag.toLowerCase() === selectedFilter.toLowerCase());
  });

  return (
    <section ref={ref} id="gallery" className="bg-gray-50">
      <FilterBar selectedFilter={selectedFilter} onFilterChange={setSelectedFilter} />

      <div className="max-w-7xl mx-auto px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-light tracking-tight text-gray-900 mb-4">
            Explore Brand Directions
          </h2>
          <p className="text-gray-600 text-lg">
            {filteredBrands.length} {filteredBrands.length === 1 ? 'direction' : 'directions'} available
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredBrands.map((brand, index) => (
            <BrandCard
              key={brand.id}
              brand={brand}
              onClick={() => setSelectedBrand(brand)}
              index={index}
            />
          ))}
        </div>

        {filteredBrands.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <p className="text-gray-500 text-lg">No brand directions match this filter.</p>
            <button
              onClick={() => setSelectedFilter('All')}
              className="mt-4 text-gray-900 underline hover:no-underline"
            >
              View all directions
            </button>
          </motion.div>
        )}
      </div>

      <BrandModal
        brand={selectedBrand}
        onClose={() => setSelectedBrand(null)}
        onPreference={onPreference}
      />
    </section>
  );
}
