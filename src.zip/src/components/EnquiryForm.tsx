import { motion } from 'framer-motion';
import { useRef, useState } from 'react';
import { useInView } from 'framer-motion';
import { Send, CheckCircle } from 'lucide-react';

export default function EnquiryForm() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <section ref={ref} className="py-32 px-6 bg-gray-900 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8 }}
        className="max-w-3xl mx-auto relative"
      >
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-light tracking-tight text-white mb-6">
            Ready to bring your
            <br />
            <span className="italic">brand to life?</span>
          </h2>
          <p className="text-gray-400 text-lg">
            Let's create something extraordinary together
          </p>
        </div>

        {isSubmitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white/10 backdrop-blur-sm border border-white/20 p-12 text-center"
          >
            <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
            <h3 className="text-2xl text-white font-light mb-2">Thank you!</h3>
            <p className="text-gray-300">We'll be in touch within 24 hours to discuss your brand vision.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label htmlFor="name" className="block text-sm text-gray-400 tracking-wider uppercase">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  className="w-full px-4 py-4 bg-white/5 border border-white/10 text-white
                           placeholder-gray-500 focus:border-white/30 focus:outline-none
                           transition-colors"
                  placeholder="Jane Doe"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="block text-sm text-gray-400 tracking-wider uppercase">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  className="w-full px-4 py-4 bg-white/5 border border-white/10 text-white
                           placeholder-gray-500 focus:border-white/30 focus:outline-none
                           transition-colors"
                  placeholder="jane@company.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="company" className="block text-sm text-gray-400 tracking-wider uppercase">
                Company or Brand Name
              </label>
              <input
                type="text"
                id="company"
                className="w-full px-4 py-4 bg-white/5 border border-white/10 text-white
                         placeholder-gray-500 focus:border-white/30 focus:outline-none
                         transition-colors"
                placeholder="Your Company"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="message" className="block text-sm text-gray-400 tracking-wider uppercase">
                Tell us about your project
              </label>
              <textarea
                id="message"
                rows={6}
                required
                className="w-full px-4 py-4 bg-white/5 border border-white/10 text-white
                         placeholder-gray-500 focus:border-white/30 focus:outline-none
                         transition-colors resize-none"
                placeholder="What are you looking to create? Share your vision, goals, and timeline..."
              />
            </div>

            <motion.button
              type="submit"
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              className="w-full flex items-center justify-center gap-3 px-8 py-5 bg-white
                       text-gray-900 hover:bg-gray-100 transition-colors group"
            >
              <span className="text-sm tracking-wider uppercase font-medium">Send Enquiry</span>
              <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </form>
        )}
      </motion.div>
    </section>
  );
}
