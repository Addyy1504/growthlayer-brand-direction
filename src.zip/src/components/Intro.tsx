import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

export default function Intro() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-32 px-6 bg-white relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-16 bg-gradient-to-b from-transparent via-gray-300 to-transparent" />

      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center space-y-8"
        >
          <h2 className="text-4xl md:text-5xl font-light tracking-tight text-gray-900">
            Your brand is your{' '}
            <span className="italic font-light">first impression</span>
          </h2>

          <div className="w-16 h-px bg-gray-300 mx-auto" />

          <p className="text-lg text-gray-600 leading-relaxed max-w-3xl mx-auto font-light">
            Every color, typeface, and visual element communicates something about who you are.
            The right brand direction builds instant trust, attracts your ideal clients,
            and positions you exactly where you belong in the market.
          </p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="pt-8"
          >
            <p className="text-sm text-gray-500 tracking-wider uppercase">
              Let's find your perfect aesthetic
            </p>
          </motion.div>
        </motion.div>
      </div>

      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-px h-16 bg-gradient-to-b from-gray-300 via-transparent to-transparent" />
    </section>
  );
}
