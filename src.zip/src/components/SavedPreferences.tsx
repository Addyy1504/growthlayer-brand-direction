import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Bookmark, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface Preference {
  brandId: number;
  brandName: string;
  preference: 'love' | 'maybe' | 'no';
}

interface SavedPreferencesProps {
  preferences: Preference[];
}

export default function SavedPreferences({ preferences }: SavedPreferencesProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const lovedBrands = preferences.filter((p) => p.preference === 'love');
  const maybeBrands = preferences.filter((p) => p.preference === 'maybe');
  const totalCount = lovedBrands.length + maybeBrands.length;

  if (totalCount === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-8 right-8 z-40 w-80"
    >
      <div className="bg-white border-2 border-gray-900 shadow-2xl overflow-hidden">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full px-6 py-4 bg-gray-900 text-white flex items-center justify-between hover:bg-gray-800 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 fill-current" />
              <span className="font-medium">{totalCount}</span>
            </div>
            <span className="text-sm">Saved Preferences</span>
          </div>
          {isExpanded ? (
            <ChevronDown className="w-5 h-5" />
          ) : (
            <ChevronUp className="w-5 h-5" />
          )}
        </button>

        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="p-6 space-y-6 max-h-96 overflow-y-auto">
                {lovedBrands.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm uppercase tracking-wider text-gray-500">
                      <Heart className="w-4 h-4" />
                      <span>Loved ({lovedBrands.length})</span>
                    </div>
                    <div className="space-y-2">
                      {lovedBrands.map((pref) => (
                        <div
                          key={pref.brandId}
                          className="px-3 py-2 bg-gray-50 text-sm text-gray-900"
                        >
                          {pref.brandName}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {maybeBrands.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm uppercase tracking-wider text-gray-500">
                      <Bookmark className="w-4 h-4" />
                      <span>Maybe ({maybeBrands.length})</span>
                    </div>
                    <div className="space-y-2">
                      {maybeBrands.map((pref) => (
                        <div
                          key={pref.brandId}
                          className="px-3 py-2 bg-gray-50 text-sm text-gray-900"
                        >
                          {pref.brandName}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
