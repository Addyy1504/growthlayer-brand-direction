import { motion } from 'framer-motion';

const filters = [
  'All',
  'Luxury',
  'Modern',
  'Organic',
  'Playful',
  'Feminine',
  'Masculine',
  'Minimal',
  'Bold',
  'Tech',
  'Corporate',
  'Premium',
  'Gen Z',
];

interface FilterBarProps {
  selectedFilter: string;
  onFilterChange: (filter: string) => void;
}

export default function FilterBar({ selectedFilter, onFilterChange }: FilterBarProps) {
  return (
    <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-gray-200/50">
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm tracking-wider uppercase text-gray-500 font-light">
            Filter by Style
          </h3>
          {selectedFilter !== 'All' && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              onClick={() => onFilterChange('All')}
              className="text-xs text-gray-500 hover:text-gray-900 underline transition-colors"
            >
              Clear filter
            </motion.button>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {filters.map((filter) => (
            <motion.button
              key={filter}
              onClick={() => onFilterChange(filter)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`px-5 py-2.5 text-sm tracking-wide transition-all duration-300
                        ${
                          selectedFilter === filter
                            ? 'bg-gray-900 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
            >
              {filter}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
